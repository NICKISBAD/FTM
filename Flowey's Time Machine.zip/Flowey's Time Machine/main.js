const electron = require('electron');
const { app, BrowserWindow } = electron;

let mainWindow;

app.on('ready', () => {
    mainWindow = new BrowserWindow({
        width: 1000,
        height: 700,
	icon: 'Icon\flowey_evil'
    });

    mainWindow.setTitle("Flowey's Time Machine (Windows 10 Edition)");
    mainWindow.loadURL('https://crumblingstatue.github.io/FloweysTimeMachine/');

    mainWindow.on('closed', () => {
        mainWindow = null;
    });
});